@echo off
chcp 65001 >nul
title EX-IPTV Build
echo ============================================
echo    EX-IPTV  -  Build fuer Windows
echo ============================================
echo.

REM --- .NET SDK vorhanden? ---
where dotnet >nul 2>nul
if errorlevel 1 (
    echo [FEHLER] .NET 8 SDK ist nicht installiert.
    echo.
    echo Bitte einmalig installieren ^(kostenlos^):
    echo   https://dotnet.microsoft.com/download/dotnet/8.0
    echo Dort "SDK 8.0.x" fuer Windows x64 waehlen, installieren,
    echo danach diese Datei erneut doppelklicken.
    echo.
    pause
    exit /b 1
)

echo [1/3] Pakete werden geladen...
dotnet restore EXIPTV.sln
if errorlevel 1 goto fehler

echo.
echo [2/3] App wird gebaut ^(dauert 1-3 Minuten^)...
dotnet publish EXIPTV\EXIPTV.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -o "%~dp0publish"
if errorlevel 1 goto fehler

echo.
echo ============================================
echo    APP FERTIG
echo ============================================
echo Ordner:  publish
echo Starten: publish\EX-IPTV.exe
echo.

REM --- [3/3] Optional: Installer, falls Inno Setup installiert ---
set "ISCC=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" (
    echo [3/3] Installer wird erstellt...
    "%ISCC%" installer.iss
    if exist "Output\EX-IPTV-Setup.exe" (
        echo.
        echo INSTALLER FERTIG:  Output\EX-IPTV-Setup.exe
    )
) else (
    echo [3/3] Inno Setup nicht gefunden - Installer uebersprungen.
    echo       ^(Optional: https://jrsoftware.org/isdl.php  installieren,
    echo        dann diese Datei erneut ausfuehren fuer eine Setup.exe^)
)

echo.
echo Fertig. Du kannst dieses Fenster schliessen.
pause
exit /b 0

:fehler
echo.
echo [FEHLER] Build fehlgeschlagen. Bitte die Meldungen oben pruefen.
echo Bei Bedarf den Text hier kopieren und mir schicken.
pause
exit /b 1
