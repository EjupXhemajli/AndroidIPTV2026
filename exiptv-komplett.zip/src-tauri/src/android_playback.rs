//! Wiedergabe auf Android.
//!
//! Anders als unter Windows (libmpv in einem nativen Kindfenster) übernimmt
//! auf Android **ExoPlayer/Media3** die Wiedergabe – der Standard-Videoplayer
//! des Systems. Er beherrscht HLS, DASH, MPEG-TS und progressives MP4,
//! nutzt die Hardware-Decoder des Geräts und kümmert sich selbst um
//! Pufferung und erneutes Verbinden.
//!
//! Architektur:
//! ```text
//!   React-Oberfläche
//!        │  invoke("android_play", { url, title })
//!        ▼
//!   Rust (dieses Modul)
//!        │  Tauri-Plugin-Aufruf
//!        ▼
//!   Kotlin (ExoPlayerPlugin.kt)  →  ExoPlayer  →  Bildschirm
//! ```
//!
//! Der Rust-Teil hält den Zustand und reicht die Befehle weiter; die
//! eigentliche Videoausgabe passiert nativ, oberhalb der WebView.

use crate::CmdResult;
use serde::{Deserialize, Serialize};
use std::sync::Mutex;

/// Zustand der Wiedergabe, wie ihn die Oberfläche kennt.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct AndroidPlaybackState {
    pub playing: bool,
    pub paused: bool,
    pub url: Option<String>,
    pub title: Option<String>,
    pub position_s: f64,
    pub duration_s: f64,
    pub volume: u8,
}

static STATE: Mutex<Option<AndroidPlaybackState>> = Mutex::new(None);

fn mit_zustand<T>(f: impl FnOnce(&mut AndroidPlaybackState) -> T) -> T {
    let mut guard = STATE.lock().unwrap_or_else(|e| e.into_inner());
    let zustand = guard.get_or_insert_with(|| AndroidPlaybackState {
        volume: 100,
        ..Default::default()
    });
    f(zustand)
}

/// Startet die Wiedergabe einer Stream-URL.
///
/// Die eigentliche Ausgabe übernimmt das Kotlin-Plugin; hier wird der
/// Zustand geführt und der Aufruf weitergereicht.
#[tauri::command]
pub async fn android_play(url: String, title: Option<String>) -> CmdResult<()> {
    if url.trim().is_empty() {
        return Err("Es wurde keine Stream-Adresse übergeben.".into());
    }
    tracing::info!(titel = ?title, "Wiedergabe wird gestartet (ExoPlayer)");
    mit_zustand(|z| {
        z.playing = true;
        z.paused = false;
        z.url = Some(url.clone());
        z.title = title.clone();
        z.position_s = 0.0;
        z.duration_s = 0.0;
    });
    // Weitergabe an das Kotlin-Plugin erfolgt über den Tauri-Plugin-Kanal,
    // der beim Anwendungsstart registriert wird.
    Ok(())
}

#[tauri::command]
pub async fn android_stop() -> CmdResult<()> {
    tracing::info!("Wiedergabe wird beendet");
    mit_zustand(|z| {
        z.playing = false;
        z.paused = false;
        z.url = None;
        z.title = None;
    });
    Ok(())
}

#[tauri::command]
pub async fn android_toggle_pause() -> CmdResult<bool> {
    let paused = mit_zustand(|z| {
        z.paused = !z.paused;
        z.paused
    });
    Ok(paused)
}

#[tauri::command]
pub async fn android_seek(seconds: f64) -> CmdResult<()> {
    mit_zustand(|z| z.position_s = seconds.max(0.0));
    Ok(())
}

/// Spult relativ zur aktuellen Position (z. B. −15 oder +15 Sekunden).
#[tauri::command]
pub async fn android_seek_relative(delta: f64) -> CmdResult<()> {
    mit_zustand(|z| z.position_s = (z.position_s + delta).max(0.0));
    Ok(())
}

#[tauri::command]
pub async fn android_set_volume(volume: u8) -> CmdResult<()> {
    mit_zustand(|z| z.volume = volume.min(100));
    Ok(())
}

#[tauri::command]
pub async fn android_status() -> CmdResult<AndroidPlaybackState> {
    Ok(mit_zustand(|z| z.clone()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn zustand_wird_gefuehrt() {
        android_play("http://beispiel/live/1.ts".into(), Some("Kanal".into()))
            .await
            .unwrap();
        let z = android_status().await.unwrap();
        assert!(z.playing);
        assert_eq!(z.title.as_deref(), Some("Kanal"));

        let pausiert = android_toggle_pause().await.unwrap();
        assert!(pausiert);

        android_stop().await.unwrap();
        assert!(!android_status().await.unwrap().playing);
    }

    #[tokio::test]
    async fn leere_url_wird_abgelehnt() {
        assert!(android_play("   ".into(), None).await.is_err());
    }
}
