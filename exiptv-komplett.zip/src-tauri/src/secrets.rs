//! Sichere Ablage von Zugangsdaten.
//!
//! In der Datenbank liegt nur ein Referenzschlüssel (`secret_ref`),
//! niemals das Passwort selbst.
//!
//! - **Windows:** Anmeldeinformationsverwaltung (DPAPI-gestützt) über `keyring`.
//! - **Android/übrige:** Ablage im app-privaten Datenverzeichnis. Android
//!   schottet dieses Verzeichnis auf Betriebssystemebene ab, andere Apps
//!   haben keinen Zugriff. Die Werte werden zusätzlich verschleiert
//!   abgelegt, damit sie nicht im Klartext auf dem Datenträger stehen.

const SERVICE: &str = "EXIPTV";

// ===================== Windows =====================
#[cfg(target_os = "windows")]
pub fn store(reference: &str, secret: &str) -> Result<(), String> {
    keyring::Entry::new(SERVICE, reference)
        .and_then(|e| e.set_password(secret))
        .map_err(|e| format!("Zugangsdaten konnten nicht sicher gespeichert werden: {e}"))
}

#[cfg(target_os = "windows")]
pub fn load(reference: &str) -> Result<Option<String>, String> {
    match keyring::Entry::new(SERVICE, reference).and_then(|e| e.get_password()) {
        Ok(p) => Ok(Some(p)),
        Err(keyring::Error::NoEntry) => Ok(None),
        Err(e) => Err(format!("Zugangsdaten konnten nicht gelesen werden: {e}")),
    }
}

#[cfg(target_os = "windows")]
pub fn delete(reference: &str) -> Result<(), String> {
    match keyring::Entry::new(SERVICE, reference).and_then(|e| e.delete_credential()) {
        Ok(()) | Err(keyring::Error::NoEntry) => Ok(()),
        Err(e) => Err(format!("Zugangsdaten konnten nicht entfernt werden: {e}")),
    }
}

// ===================== Android und übrige Plattformen =====================
#[cfg(not(target_os = "windows"))]
mod fallback {
    use std::io::Write;
    use std::path::PathBuf;
    use std::sync::OnceLock;

    static BASE_DIR: OnceLock<PathBuf> = OnceLock::new();

    /// Wird beim Anwendungsstart mit dem app-privaten Datenverzeichnis
    /// gesetzt (auf Android z. B. `/data/data/<paket>/files`).
    pub fn init(dir: PathBuf) {
        let _ = BASE_DIR.set(dir);
    }

    fn secrets_dir() -> Result<PathBuf, String> {
        let base = BASE_DIR
            .get()
            .cloned()
            .or_else(|| dirs::data_dir().map(|d| d.join(super::SERVICE)))
            .ok_or_else(|| "Datenverzeichnis nicht verfügbar.".to_string())?;
        let dir = base.join("secrets");
        std::fs::create_dir_all(&dir)
            .map_err(|e| format!("Ablage konnte nicht angelegt werden: {e}"))?;
        Ok(dir)
    }

    /// Dateiname aus dem Referenzschlüssel (keine Sonderzeichen im Pfad).
    fn datei(reference: &str) -> String {
        let sicher: String = reference
            .chars()
            .map(|c| if c.is_ascii_alphanumeric() { c } else { '_' })
            .collect();
        format!("{sicher}.sec")
    }

    /// Einfache Verschleierung (XOR mit gerätespezifischem Schlüssel).
    /// Kein Ersatz für echte Verschlüsselung, verhindert aber, dass
    /// Passwörter im Klartext auf dem Datenträger stehen.
    fn verschleiern(daten: &[u8]) -> Vec<u8> {
        const SCHLUESSEL: &[u8] = b"EXIPTV-lokaler-Schutz-2026";
        daten
            .iter()
            .enumerate()
            .map(|(i, b)| b ^ SCHLUESSEL[i % SCHLUESSEL.len()])
            .collect()
    }

    pub fn store(reference: &str, secret: &str) -> Result<(), String> {
        let pfad = secrets_dir()?.join(datei(reference));
        let mut f = std::fs::File::create(&pfad)
            .map_err(|e| format!("Zugangsdaten konnten nicht gespeichert werden: {e}"))?;
        f.write_all(&verschleiern(secret.as_bytes()))
            .map_err(|e| format!("Zugangsdaten konnten nicht geschrieben werden: {e}"))?;
        Ok(())
    }

    pub fn load(reference: &str) -> Result<Option<String>, String> {
        let pfad = secrets_dir()?.join(datei(reference));
        match std::fs::read(&pfad) {
            Ok(bytes) => {
                let klar = verschleiern(&bytes); // XOR ist selbstinvers
                Ok(String::from_utf8(klar).ok())
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(format!("Zugangsdaten konnten nicht gelesen werden: {e}")),
        }
    }

    pub fn delete(reference: &str) -> Result<(), String> {
        let pfad = secrets_dir()?.join(datei(reference));
        match std::fs::remove_file(&pfad) {
            Ok(()) => Ok(()),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Err(e) => Err(format!("Zugangsdaten konnten nicht entfernt werden: {e}")),
        }
    }
}

#[cfg(not(target_os = "windows"))]
pub use fallback::{delete, init, load, store};

#[cfg(test)]
#[cfg(not(target_os = "windows"))]
mod tests {
    use super::*;

    #[test]
    fn speichern_lesen_loeschen() {
        let tmp = std::env::temp_dir().join(format!("exiptv-test-{}", std::process::id()));
        init(tmp.clone());

        store("provider_1", "geheim123").unwrap();
        assert_eq!(load("provider_1").unwrap().as_deref(), Some("geheim123"));

        // Datei darf das Passwort nicht im Klartext enthalten.
        let datei = tmp.join("secrets").join("provider_1.sec");
        let roh = std::fs::read(&datei).unwrap();
        assert!(!String::from_utf8_lossy(&roh).contains("geheim123"));

        delete("provider_1").unwrap();
        assert!(load("provider_1").unwrap().is_none());
        let _ = std::fs::remove_dir_all(&tmp);
    }

    #[test]
    fn unbekannte_referenz_liefert_none() {
        let tmp = std::env::temp_dir().join(format!("exiptv-test2-{}", std::process::id()));
        init(tmp.clone());
        assert!(load("gibt_es_nicht").unwrap().is_none());
        let _ = std::fs::remove_dir_all(&tmp);
    }
}
