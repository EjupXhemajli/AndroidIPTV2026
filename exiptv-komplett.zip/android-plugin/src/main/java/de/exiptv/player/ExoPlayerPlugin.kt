package de.exiptv.player

import android.app.Activity
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import app.tauri.annotation.Command
import app.tauri.annotation.TauriPlugin
import app.tauri.plugin.JSObject
import app.tauri.plugin.Invoke
import app.tauri.plugin.Plugin

/**
 * Wiedergabe für EXIPTV auf Android – gebaut auf ExoPlayer (Media3).
 *
 * ExoPlayer ist der Standard-Videoplayer von Android und beherrscht die
 * Formate, die IPTV-Anbieter liefern: MPEG-TS (die häufigen .ts-Streams),
 * HLS (.m3u8), DASH und progressives MP4/MKV. Er nutzt die Hardware-Decoder
 * des Geräts, was Akku schont und auch 4K-Streams flüssig hält.
 *
 * Der PlayerView liegt als eigene Ansicht **über** der WebView. Die
 * Bedienelemente zeichnet weiterhin die Weboberfläche; dieser Player
 * liefert nur das Bild. So bleibt das Aussehen auf allen Plattformen gleich.
 */
@TauriPlugin
class ExoPlayerPlugin(private val activity: Activity) : Plugin(activity) {

    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null

    /** Erzeugt Player und Ansicht beim ersten Gebrauch. */
    private fun ensurePlayer(): ExoPlayer {
        player?.let { return it }

        // HTTP-Quelle mit einem User-Agent, den IPTV-Server akzeptieren.
        // Viele Anbieter weisen unbekannte Programme ab.
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("VLC/3.0.20 LibVLC/3.0.20")
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(30_000)
            .setAllowCrossProtocolRedirects(true)

        val exo = ExoPlayer.Builder(activity)
            .setMediaSourceFactory(DefaultMediaSourceFactory(httpFactory))
            .build()

        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                val name = when (state) {
                    Player.STATE_BUFFERING -> "buffering"
                    Player.STATE_READY -> "playing"
                    Player.STATE_ENDED -> "ended"
                    else -> "idle"
                }
                trigger("playbackState", JSObject().put("state", name))
            }

            override fun onPlayerError(error: PlaybackException) {
                // Verständliche Meldung statt technischem Fehlercode.
                val meldung = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                        "Keine Verbindung zum Server. Bitte Internetverbindung prüfen."
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                        "Der Anbieter hat die Anfrage abgelehnt. Bitte Zugangsdaten prüfen."
                    PlaybackException.ERROR_CODE_DECODING_FAILED,
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
                        "Dieses Format kann das Gerät nicht abspielen."
                    else ->
                        "Der Sender konnte nicht geladen werden. EXIPTV versucht es erneut."
                }
                trigger("playbackError", JSObject().put("message", meldung))
            }
        })

        // Ansicht über die WebView legen.
        val view = PlayerView(activity).apply {
            useController = false          // Bedienung macht die Weboberfläche
            setShutterBackgroundColor(0xFF060A18.toInt())
        }
        view.player = exo

        activity.runOnUiThread {
            val root = activity.findViewById<FrameLayout>(android.R.id.content)
            root.addView(
                view,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
            // WebView transparent schalten, damit das Video sichtbar ist
            // und die Bedienelemente darüber liegen.
            findWebView(root)?.let { web ->
                web.setBackgroundColor(0x00000000)
                web.bringToFront()
            }
        }

        player = exo
        playerView = view
        return exo
    }

    /** Sucht die WebView im Ansichtsbaum. */
    private fun findWebView(view: android.view.View): WebView? {
        if (view is WebView) return view
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                findWebView(view.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    @Command
    fun play(invoke: Invoke) {
        val url = invoke.parseArgs(PlayArgs::class.java).url
        if (url.isNullOrBlank()) {
            invoke.reject("Es wurde keine Stream-Adresse übergeben.")
            return
        }
        activity.runOnUiThread {
            try {
                val exo = ensurePlayer()
                exo.setMediaItem(MediaItem.fromUri(url))
                exo.prepare()
                exo.playWhenReady = true
                playerView?.visibility = android.view.View.VISIBLE
                invoke.resolve()
            } catch (e: Exception) {
                invoke.reject("Wiedergabe konnte nicht gestartet werden: ${e.message}")
            }
        }
    }

    @Command
    fun stop(invoke: Invoke) {
        activity.runOnUiThread {
            player?.stop()
            player?.clearMediaItems()
            playerView?.visibility = android.view.View.GONE
            invoke.resolve()
        }
    }

    @Command
    fun togglePause(invoke: Invoke) {
        activity.runOnUiThread {
            val exo = player
            if (exo == null) { invoke.resolve(JSObject().put("paused", false)); return@runOnUiThread }
            exo.playWhenReady = !exo.playWhenReady
            invoke.resolve(JSObject().put("paused", !exo.playWhenReady))
        }
    }

    @Command
    fun seek(invoke: Invoke) {
        val sekunden = invoke.parseArgs(SeekArgs::class.java).seconds ?: 0.0
        activity.runOnUiThread {
            player?.seekTo((sekunden * 1000).toLong())
            invoke.resolve()
        }
    }

    @Command
    fun seekRelative(invoke: Invoke) {
        val delta = invoke.parseArgs(SeekArgs::class.java).seconds ?: 0.0
        activity.runOnUiThread {
            player?.let { exo ->
                val ziel = (exo.currentPosition + (delta * 1000).toLong()).coerceAtLeast(0L)
                exo.seekTo(ziel)
            }
            invoke.resolve()
        }
    }

    @Command
    fun setVolume(invoke: Invoke) {
        val lautstaerke = invoke.parseArgs(VolumeArgs::class.java).volume ?: 100
        activity.runOnUiThread {
            player?.volume = (lautstaerke.coerceIn(0, 100)) / 100f
            invoke.resolve()
        }
    }

    @Command
    fun status(invoke: Invoke) {
        activity.runOnUiThread {
            val exo = player
            val ergebnis = JSObject()
                .put("playing", exo?.isPlaying ?: false)
                .put("paused", exo?.playWhenReady?.not() ?: false)
                .put("position", (exo?.currentPosition ?: 0L) / 1000.0)
                .put("duration", if ((exo?.duration ?: -1L) > 0) (exo!!.duration) / 1000.0 else 0.0)
                .put("volume", ((exo?.volume ?: 1f) * 100).toInt())
            invoke.resolve(ergebnis)
        }
    }

    override fun onDestroy() {
        activity.runOnUiThread {
            player?.release()
            player = null
            playerView = null
        }
        super.onDestroy()
    }

    // Argument-Klassen für die Befehle
    class PlayArgs { var url: String? = null; var title: String? = null }
    class SeekArgs { var seconds: Double? = null }
    class VolumeArgs { var volume: Int? = null }
}
