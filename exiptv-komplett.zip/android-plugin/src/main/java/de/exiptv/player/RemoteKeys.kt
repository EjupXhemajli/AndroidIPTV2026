package de.exiptv.player

import android.view.KeyEvent
import android.webkit.WebView

/**
 * Weiterleitung der Fernbedienungstasten an die Weboberfläche.
 *
 * Auf Fernsehern (Fire TV, Formuler, Philips/Sony Android TV) kommen die
 * Tasten als Android-KeyEvents an. Die Weboberfläche kennt sie jedoch nur
 * als Tastatur-Ereignisse. Diese Hilfsklasse übersetzt zwischen beiden Welten.
 *
 * Besonders wichtig ist die **Zurück-Taste**: Android würde damit sonst
 * sofort die App schließen. Stattdessen reichen wir sie an die Oberfläche
 * weiter, die dann eine Ebene zurückgeht – und beim zweiten Druck kurz
 * hintereinander nachfragt, ob wirklich beendet werden soll.
 */
object RemoteKeys {

    /**
     * Übersetzt ein Android-KeyEvent in einen Tastennamen, wie ihn die
     * Weboberfläche erwartet. Gibt `null` zurück, wenn die Taste normal
     * behandelt werden soll.
     */
    fun tastenName(keyCode: Int): String? = when (keyCode) {
        KeyEvent.KEYCODE_DPAD_UP -> "ArrowUp"
        KeyEvent.KEYCODE_DPAD_DOWN -> "ArrowDown"
        KeyEvent.KEYCODE_DPAD_LEFT -> "ArrowLeft"
        KeyEvent.KEYCODE_DPAD_RIGHT -> "ArrowRight"
        KeyEvent.KEYCODE_DPAD_CENTER,
        KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_NUMPAD_ENTER -> "Enter"
        KeyEvent.KEYCODE_BACK -> "GoBack"
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
        KeyEvent.KEYCODE_MEDIA_PLAY,
        KeyEvent.KEYCODE_MEDIA_PAUSE -> " "          // Leertaste = Pause
        KeyEvent.KEYCODE_MEDIA_STOP -> "Escape"
        KeyEvent.KEYCODE_MEDIA_NEXT,
        KeyEvent.KEYCODE_CHANNEL_UP -> "PageUp"
        KeyEvent.KEYCODE_MEDIA_PREVIOUS,
        KeyEvent.KEYCODE_CHANNEL_DOWN -> "PageDown"
        KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> "ArrowRight"
        KeyEvent.KEYCODE_MEDIA_REWIND -> "ArrowLeft"
        KeyEvent.KEYCODE_INFO,
        KeyEvent.KEYCODE_MENU -> "Enter"             // Info/Menü = Steuerung zeigen
        else -> null
    }

    /**
     * Schickt ein Tastenereignis an die Weboberfläche.
     *
     * Der Umweg über JavaScript ist nötig, weil ein WebView die
     * Fernbedienungstasten sonst nicht als Tastatur-Ereignisse sieht.
     */
    fun anWebViewSenden(webView: WebView, taste: String) {
        val js = """
            (function () {
              var e = new KeyboardEvent('keydown', {
                key: ${jsonString(taste)},
                bubbles: true,
                cancelable: true
              });
              (document.activeElement || document.body).dispatchEvent(e);
              window.dispatchEvent(e);
            })();
        """.trimIndent()
        webView.post { webView.evaluateJavascript(js, null) }
    }

    /** Erzeugt eine sichere JavaScript-Zeichenkette. */
    private fun jsonString(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                else -> sb.append(c)
            }
        }
        return sb.append("\"").toString()
    }
}
