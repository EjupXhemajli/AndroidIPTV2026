// Gradle-Konfiguration für das EXIPTV-Wiedergabe-Plugin (ExoPlayer/Media3).
//
// Wird beim Android-Build von Tauri eingebunden. Die Media3-Bibliotheken
// liefern die Videowiedergabe; androidx.media3.exoplayer.hls und .dash
// ergänzen die Unterstützung für HLS- und DASH-Streams.

plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.exiptv.player"
    compileSdk = 35

    defaultConfig {
        minSdk = 24            // Android 7.0 – deckt praktisch alle Geräte ab
        targetSdk = 35
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Tauri-Plugin-Schnittstelle
    implementation(project(":tauri-android"))

    // ExoPlayer / Media3 – Videowiedergabe
    val media3 = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")     // HLS (.m3u8)
    implementation("androidx.media3:media3-exoplayer-dash:$media3")    // DASH
    implementation("androidx.media3:media3-ui:$media3")                // PlayerView
    implementation("androidx.media3:media3-datasource-okhttp:$media3") // stabiles HTTP

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
