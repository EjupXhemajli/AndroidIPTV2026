# EXIPTV für Android

## Wo wir stehen

**Fertig in diesem Schritt:**

| Baustein | Zustand |
|---|---|
| Kern (Parser, Datenbank, Suche, RSS) | ✅ läuft unverändert, 55 Tests grün |
| Plattform-Trennung (mpv nur Windows) | ✅ |
| Zugangsdaten-Ablage für Android | ✅ app-privater Ordner, verschleiert |
| ExoPlayer-Plugin (Kotlin) | ✅ geschrieben, in der CI zu bauen |
| Touch-Oberfläche | ✅ Navigation unten, große Trefferflächen |
| Build-Workflow (APK) | ✅ `.github/workflows/android-build.yml` |

**Noch offen:**

- Erster echter Android-Build in der CI (dabei zeigen sich erfahrungsgemäß
  noch Kleinigkeiten: Gradle-Versionen, Plugin-Registrierung)
- Verbindung Rust ↔ Kotlin-Plugin scharfschalten
- Test auf einem echten Gerät

## Warum ExoPlayer statt mpv

mpv gibt es auf Android nicht in nutzbarer Form. ExoPlayer (Media3) ist
Androids Standard-Videoplayer und beherrscht genau die Formate, die
IPTV-Anbieter liefern:

- **MPEG-TS** (`.ts`) – das Format deiner Sender
- **HLS** (`.m3u8`)
- **DASH**
- progressives MP4/MKV für Filme

Er nutzt die Hardware-Decoder des Telefons, was den Akku schont und auch
4K flüssig hält.

## Aufbau

```
React-Oberfläche  (dieselbe wie am PC, für Touch angepasst)
      │  invoke("android_play", …)
      ▼
Rust  (src-tauri/src/android_playback.rs – führt den Zustand)
      │  Tauri-Plugin-Aufruf
      ▼
Kotlin (android-plugin/…/ExoPlayerPlugin.kt)
      ▼
ExoPlayer → Bildschirm
```

Der Videoplayer liegt als eigene Ansicht **über** der WebView; die
Bedienelemente zeichnet weiterhin die Weboberfläche. Dadurch sieht die App
auf Telefon und PC gleich aus.

## Build

Der Workflow **„EXIPTV Android-Build (APK)"** läuft auf Anforderung
(Actions → Workflow auswählen → „Run workflow") oder automatisch bei
Änderungen. Er installiert Java 17, Android-SDK und NDK, baut das Frontend,
erzeugt das Gradle-Projekt und daraus die APK.

Ergebnis: unter **Releases → „EXIPTV Android – aktueller Build"** und als
Artefakt am Build.

## Installation auf dem Telefon

1. APK aus dem Release herunterladen.
2. Öffnen. Android fragt nach der Erlaubnis für „unbekannte Quellen" –
   das ist bei selbst gebauten Apps normal.
3. Installieren.

## Unterschiede zur Windows-Fassung

| | Windows | Android |
|---|---|---|
| Player | libmpv | ExoPlayer |
| Zugangsdaten | Anmeldeinformationsverwaltung | app-privater Ordner |
| Navigation | Seitenleiste links | Leiste unten |
| Kategorien | Spalte links, ziehbar | waagerechte Leiste oben |
| Senderliste im Player | Maus oben links | Tippen auf die Bildmitte |
| Vollbild | F-Taste / Doppelklick | Gerät drehen / Vollbild-Taste |

---

## Fernbedienung und Fernseher-Geräte

Getestet gedacht für: **Fire TV Stick, Formuler, Philips/Sony Android TV,
Nvidia Shield** – und normale Telefone.

### Manifest-Einträge (setzt `scripts/android-nachbereiten.py`)

| Eintrag | Wozu |
|---|---|
| `android.software.leanback` (required=false) | App erscheint auf Fernsehern **und** auf Telefonen |
| `android.hardware.touchscreen` (required=false) | Ohne diesen Eintrag verweigern Fernseher die Installation |
| `LEANBACK_LAUNCHER` | App taucht im Startbildschirm des Fernsehers auf |
| `android:banner` | Kachelbild in der Fire-TV-Oberfläche |
| `usesCleartextTraffic` | Viele IPTV-Server liefern über http:// |

### Tastenbelegung

| Fernbedienung | Wirkung |
|---|---|
| Steuerkreuz | Fokus zum räumlich nächsten Element |
| OK | Auslösen; im laufenden Stream: Steuerung einblenden, dann Senderliste |
| Zurück (1×) | Eine Ebene zurück |
| Zurück (2× kurz hintereinander) | Rückfrage „Beenden?" |
| Kanal +/− | Sender wechseln |
| Wiedergabe/Pause | Pause umschalten |
| Vor-/Zurückspulen | ±15 Sekunden |
| Info/Menü | Steuerung einblenden |

### Stabilität auf schwachen Geräten

- **Speichergrenze:** Höchstens 3.000 Sender bzw. 900 Filme/Serien werden
  gleichzeitig gehalten. Ein Fire TV Stick hat oft nur 1 GB Arbeitsspeicher;
  ohne Grenze würde das Blättern durch sehr große Listen zum Absturz führen.
  Über Kategorien und Suche bleibt jeder Eintrag erreichbar.
- **Ältere Browser:** Rückfalllösungen für `aspect-ratio`, `inset`,
  `backdrop-filter` und `gap`, damit die Oberfläche auch auf betagten
  WebView-Versionen nicht zerfällt.
- **Fokus:** Auf großen Bildschirmen kräftiger Rahmen mit Leuchten, damit
  aus mehreren Metern Entfernung erkennbar ist, wo man gerade steht.

## Was NICHT eingebaut ist

**Umgehung von Ländersperren.** Geo-Sperren werden auf dem Server des
Anbieters anhand der IP-Adresse durchgesetzt. Eine App kann ihre eigene
IP-Adresse nicht ändern – dafür wäre zwingend ein Umweg über einen Server
im Zielland nötig (VPN/Proxy). Zudem schließt die Projektvorgabe
Umgehungsfunktionen ausdrücklich aus.

Was stattdessen für zuverlässige Verbindungen sorgt: passender User-Agent,
Folgen von Weiterleitungen, großzügige Zeitlimits und erneute Versuche mit
wachsenden Wartezeiten.
