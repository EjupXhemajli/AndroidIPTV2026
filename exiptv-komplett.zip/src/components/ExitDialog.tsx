import { useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";

/**
 * Rückfrage vor dem Beenden der App.
 *
 * Erscheint, wenn zweimal kurz hintereinander die Zurück-Taste der
 * Fernbedienung gedrückt wurde. Bewusst mit großen Schaltflächen, damit
 * er auch vom Sofa aus gut lesbar und mit dem Steuerkreuz bedienbar ist.
 * Der Fokus startet auf „Abbrechen" – ein versehentliches Beenden soll
 * nicht schon durch einmaliges Drücken von OK passieren.
 */
export default function ExitDialog({
  onCancel,
  onConfirm,
}: {
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const { t } = useTranslation();
  const abbrechenRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    abbrechenRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      // Escape und Zurück schließen den Dialog ohne zu beenden.
      if (e.key === "Escape" || e.key === "Backspace" || e.key === "GoBack") {
        e.preventDefault();
        e.stopPropagation();
        onCancel();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onCancel]);

  return (
    <div className="exit-overlay" role="dialog" aria-modal="true" aria-labelledby="exit-titel">
      <div className="exit-box">
        <h2 id="exit-titel">{t("exit.title")}</h2>
        <p>{t("exit.text")}</p>
        <div className="exit-buttons">
          <button ref={abbrechenRef} className="exit-btn" onClick={onCancel}>
            {t("exit.cancel")}
          </button>
          <button className="exit-btn danger" onClick={onConfirm}>
            {t("exit.confirm")}
          </button>
        </div>
      </div>
    </div>
  );
}
