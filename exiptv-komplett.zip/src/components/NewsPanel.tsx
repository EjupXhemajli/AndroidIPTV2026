import { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { backend } from "../lib/backend";
import type { NewsItem } from "../lib/types";

/**
 * Nachrichtenbereich der Startseite.
 *
 * Besteht aus zwei Teilen, die sich dieselben Daten teilen:
 * - **Links:** die große Ansicht mit Bild, Überschrift und Zusammenfassung.
 *   Wechselt alle 10 Sekunden von selbst.
 * - **Rechts:** eine Liste weiterer Schlagzeilen mit kleinem Vorschaubild.
 *   Ein Klick darauf zeigt die Meldung in der großen Ansicht.
 *
 * Die Meldungen erscheinen sofort; fehlende Bilder werden im Hintergrund
 * von den Artikelseiten nachgeladen.
 */
const INTERVAL_MS = 10_000;

export function useNews() {
  const [items, setItems] = useState<NewsItem[] | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let aktiv = true;
    backend
      .fetchNews(4)
      .then((n) => {
        if (!aktiv) return;
        setItems(n);
        setFailed(n.length === 0);
        // Fehlende Bilder nacheinander nachladen.
        void (async () => {
          for (let i = 0; i < n.length; i++) {
            if (!aktiv) return;
            if (n[i].image_url || !n[i].link) continue;
            try {
              const bild = await backend.fetchArticleImage(n[i].link);
              if (!aktiv || !bild) continue;
              setItems((vorher) => {
                if (!vorher) return vorher;
                const kopie = [...vorher];
                if (kopie[i] && !kopie[i].image_url) {
                  kopie[i] = { ...kopie[i], image_url: bild };
                }
                return kopie;
              });
            } catch {
              /* einzelnes Bild darf fehlschlagen */
            }
          }
        })();
      })
      .catch(() => {
        if (aktiv) setFailed(true);
      });
    return () => {
      aktiv = false;
    };
  }, []);

  return { items, failed };
}

/** Farbliche Kennzeichnung je Herkunft. */
function tagKlasse(quelle: string): string {
  if (quelle === "Politik") return "politik";
  if (quelle === "Fußball") return "fussball";
  return "sport";
}

/** Bild mit Rückfalllösung über den Backend-Cache. */
function NewsBild({ url, klasse }: { url: string | null; klasse: string }) {
  const [quelle, setQuelle] = useState<string | null>(url);
  const [versucht, setVersucht] = useState(false);

  useEffect(() => {
    setQuelle(url);
    setVersucht(false);
  }, [url]);

  if (!quelle) return <div className={`${klasse}-fallback`} aria-hidden="true" />;

  return (
    <img
      src={quelle}
      alt=""
      loading="lazy"
      onError={async () => {
        // Manche Nachrichtenbilder laden nicht direkt (Hotlink-Schutz).
        if (versucht || !url) {
          setQuelle(null);
          return;
        }
        setVersucht(true);
        try {
          setQuelle(await backend.cacheImage(url));
        } catch {
          setQuelle(null);
        }
      }}
    />
  );
}

/** Große Ansicht (linke Spalte). */
export function NewsHauptansicht({
  items,
  failed,
  index,
  setIndex,
}: {
  items: NewsItem[] | null;
  failed: boolean;
  index: number;
  setIndex: (i: number) => void;
}) {
  const { t } = useTranslation();
  const [paused, setPaused] = useState(false);
  const timer = useRef<number>();

  // Automatischer Wechsel alle 10 Sekunden.
  useEffect(() => {
    if (!items || items.length < 2 || paused) return;
    timer.current = window.setTimeout(
      () => setIndex((index + 1) % items.length),
      INTERVAL_MS
    );
    return () => window.clearTimeout(timer.current);
  }, [items, index, paused, setIndex]);

  if (failed) {
    return (
      <div className="news-box news-empty">
        <p className="faint">{t("news.unavailable")}</p>
      </div>
    );
  }
  if (!items) return <div className="news-box skeleton" style={{ minHeight: 320 }} />;

  const current = items[index] ?? items[0];
  const go = (delta: number) => setIndex((index + delta + items.length) % items.length);

  return (
    <div
      className="news-box"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="news-media">
        <NewsBild url={current.image_url} klasse="news-media" />
        <span className={`news-tag ${tagKlasse(current.source)}`}>{current.source}</span>
      </div>

      <div className="news-text">
        <h3>{current.title}</h3>
        <p>{current.summary}</p>
        {current.published && <span className="faint news-date">{current.published}</span>}
      </div>

      {items.length > 1 && (
        <div className="news-controls">
          <button className="icon-btn" onClick={() => go(-1)} aria-label={t("news.prev")}>‹</button>
          <div className="news-dots" role="tablist">
            {items.map((_, i) => (
              <button
                key={i}
                className={`news-dot ${i === index ? "active" : ""}`}
                onClick={() => setIndex(i)}
                aria-label={t("news.goTo", { n: i + 1 })}
                aria-selected={i === index}
                role="tab"
              />
            ))}
          </div>
          <button className="icon-btn" onClick={() => go(1)} aria-label={t("news.next")}>›</button>
        </div>
      )}
    </div>
  );
}

/** Schlagzeilenliste (rechte Spalte). */
export function NewsListe({
  items,
  failed,
  index,
  setIndex,
}: {
  items: NewsItem[] | null;
  failed: boolean;
  index: number;
  setIndex: (i: number) => void;
}) {
  const { t } = useTranslation();

  if (failed) return null;

  if (!items) {
    return (
      <section className="card news-liste">
        <h2>{t("news.moreHeadlines")}</h2>
        <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="skeleton" style={{ height: 58 }} />
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="card news-liste">
      <h2>{t("news.moreHeadlines")}</h2>
      <div className="news-liste-eintraege">
        {items.map((n, i) => (
          <button
            key={`${n.link}-${i}`}
            className={`news-eintrag ${i === index ? "active" : ""}`}
            onClick={() => setIndex(i)}
            title={n.title}
          >
            <span className="news-eintrag-bild">
              <NewsBild url={n.image_url} klasse="news-eintrag-bild" />
            </span>
            <span className="news-eintrag-text">
              <span className={`news-tag klein ${tagKlasse(n.source)}`}>{n.source}</span>
              <span className="news-eintrag-titel">{n.title}</span>
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}
