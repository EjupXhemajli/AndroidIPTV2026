import { useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";

/**
 * Videowiedergabe auf Android über das eingebaute Videoelement der WebView.
 *
 * Auf Windows spielt EXIPTV über libmpv in einem eigenen Fenster ab. Unter
 * Android übernimmt vorerst der Videoplayer, den Android selbst mitbringt.
 * Vorteil: kein nativer Zusatzcode, läuft auf jedem Gerät vom Telefon bis
 * zum Fernseher.
 *
 * **Was damit geht:** HLS-Streams (`.m3u8`), MP4, WebM und alles, was das
 * Gerät nativ beherrscht – bei Android schließt das die gängigen
 * Film- und Serienformate ein.
 *
 * **Was damit nicht geht:** durchgehende MPEG-TS-Streams (`.ts`), wie sie
 * manche IPTV-Anbieter für Live-Sender ausliefern. Dafür braucht es den
 * nativen ExoPlayer – der ist vorbereitet (`android-plugin/`) und wird als
 * Nächstes eingebunden.
 */
export interface WebVideoProps {
  url: string;
  /** Lautstärke 0–150 (wie im übrigen Player). */
  volume: number;
  onStateChange?: (state: "loading" | "playing" | "paused" | "error" | "ended") => void;
  onTimeUpdate?: (position: number, duration: number) => void;
  onError?: (meldung: string) => void;
}

export default function WebVideo({
  url,
  volume,
  onStateChange,
  onTimeUpdate,
  onError,
}: WebVideoProps) {
  const { t } = useTranslation();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [fehler, setFehler] = useState<string | null>(null);

  // Quelle wechseln.
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !url) return;
    setFehler(null);
    onStateChange?.("loading");
    v.src = url;
    v.load();
    void v.play().catch(() => {
      // Automatische Wiedergabe kann blockiert sein – dann wartet der
      // Player auf eine Nutzeraktion, das ist kein Fehler.
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url]);

  // Lautstärke übernehmen (Videoelement kennt nur 0–1).
  useEffect(() => {
    const v = videoRef.current;
    if (v) v.volume = Math.min(1, Math.max(0, volume / 100));
  }, [volume]);

  const meldungZuFehler = (v: HTMLVideoElement): string => {
    const code = v.error?.code;
    switch (code) {
      case MediaError.MEDIA_ERR_NETWORK:
        return t("player.errNetwork");
      case MediaError.MEDIA_ERR_DECODE:
        return t("player.errDecode");
      case MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
        return t("player.errFormat");
      default:
        return t("player.errGeneric");
    }
  };

  return (
    <>
      <video
        ref={videoRef}
        className="web-video"
        playsInline
        autoPlay
        controls={false}
        onPlaying={() => { setFehler(null); onStateChange?.("playing"); }}
        onPause={() => onStateChange?.("paused")}
        onWaiting={() => onStateChange?.("loading")}
        onEnded={() => onStateChange?.("ended")}
        onTimeUpdate={(e) => {
          const v = e.currentTarget;
          onTimeUpdate?.(v.currentTime, Number.isFinite(v.duration) ? v.duration : 0);
        }}
        onError={(e) => {
          const meldung = meldungZuFehler(e.currentTarget);
          setFehler(meldung);
          onStateChange?.("error");
          onError?.(meldung);
        }}
      />
      {fehler && (
        <div className="player-error card" role="alert">
          <h3>{t("player.errorTitle")}</h3>
          <p>{fehler}</p>
        </div>
      )}
    </>
  );
}

/** Steuerbefehle für das Videoelement (von außen aufrufbar). */
export const webVideoSteuerung = {
  togglePause(el: HTMLVideoElement | null) {
    if (!el) return false;
    if (el.paused) { void el.play(); return false; }
    el.pause();
    return true;
  },
  seekRelative(el: HTMLVideoElement | null, delta: number) {
    if (!el) return;
    el.currentTime = Math.max(0, el.currentTime + delta);
  },
  seek(el: HTMLVideoElement | null, sekunden: number) {
    if (!el) return;
    el.currentTime = Math.max(0, sekunden);
  },
};
