import { useEffect, useRef } from "react";

/**
 * Fernbedienungs-Steuerung für Android-TV-Geräte
 * (Fire TV Stick, Formuler, Philips/Sony Android TV, Nvidia Shield …).
 *
 * Fernbedienungen senden ein Steuerkreuz (D-Pad): hoch, runter, links,
 * rechts, OK und Zurück. Ein Browser bewegt den Fokus damit nicht von
 * selbst – das übernimmt dieser Hook:
 *
 * - **Pfeiltasten** verschieben den Fokus zum räumlich nächsten Bedienelement.
 *   Nicht einfach das nächste im Quelltext, sondern das, was der Nutzer
 *   in dieser Richtung tatsächlich sieht.
 * - **OK/Enter** löst das fokussierte Element aus (macht der Browser selbst).
 * - **Zurück** geht eine Ebene zurück; zweimal kurz hintereinander fragt,
 *   ob die App beendet werden soll.
 *
 * Der Hook greift nur, wenn keine Texteingabe aktiv ist – sonst würde er
 * das Tippen in Suchfeldern stören.
 */

/** Alle Elemente, die den Fokus erhalten können. */
const FOKUSSIERBAR = [
  "a[href]",
  "button:not([disabled])",
  "select:not([disabled])",
  "input:not([disabled]):not([type=hidden])",
  "textarea:not([disabled])",
  '[tabindex]:not([tabindex="-1"])',
  '[role="button"]:not([disabled])',
].join(",");

interface Rechteck {
  el: HTMLElement;
  x: number;   // Mittelpunkt
  y: number;
  links: number;
  rechts: number;
  oben: number;
  unten: number;
}

function sichtbareElemente(): Rechteck[] {
  const gefunden = Array.from(
    document.querySelectorAll<HTMLElement>(FOKUSSIERBAR)
  );
  const out: Rechteck[] = [];
  for (const el of gefunden) {
    // Unsichtbare und ausgeblendete Elemente überspringen.
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) continue;
    if (r.bottom < -50 || r.top > window.innerHeight + 50) continue;
    const stil = window.getComputedStyle(el);
    if (stil.visibility === "hidden" || stil.display === "none") continue;
    out.push({
      el,
      x: r.left + r.width / 2,
      y: r.top + r.height / 2,
      links: r.left,
      rechts: r.right,
      oben: r.top,
      unten: r.bottom,
    });
  }
  return out;
}

/**
 * Sucht in der angegebenen Richtung das nächstgelegene Element.
 *
 * Bewertung: Der Abstand in Bewegungsrichtung zählt am stärksten, seitlicher
 * Versatz wird zusätzlich bestraft. So springt der Fokus nicht quer über den
 * Bildschirm, sondern dorthin, wo der Nutzer ihn erwartet.
 */
function naechstes(
  von: Rechteck,
  alle: Rechteck[],
  richtung: "up" | "down" | "left" | "right"
): HTMLElement | null {
  let bestes: HTMLElement | null = null;
  let besteBewertung = Number.POSITIVE_INFINITY;

  for (const z of alle) {
    if (z.el === von.el) continue;

    let inRichtung = false;
    let haupt = 0;   // Abstand in Bewegungsrichtung
    let quer = 0;    // seitlicher Versatz

    switch (richtung) {
      case "up":
        inRichtung = z.unten <= von.oben + 2;
        haupt = von.oben - z.unten;
        quer = Math.abs(z.x - von.x);
        break;
      case "down":
        inRichtung = z.oben >= von.unten - 2;
        haupt = z.oben - von.unten;
        quer = Math.abs(z.x - von.x);
        break;
      case "left":
        inRichtung = z.rechts <= von.links + 2;
        haupt = von.links - z.rechts;
        quer = Math.abs(z.y - von.y);
        break;
      case "right":
        inRichtung = z.links >= von.rechts - 2;
        haupt = z.links - von.rechts;
        quer = Math.abs(z.y - von.y);
        break;
    }
    if (!inRichtung) continue;

    // Seitlicher Versatz wiegt doppelt – bevorzugt geradlinige Sprünge.
    const bewertung = Math.max(0, haupt) + quer * 2;
    if (bewertung < besteBewertung) {
      besteBewertung = bewertung;
      bestes = z.el;
    }
  }
  return bestes;
}

/** Prüft, ob gerade in ein Textfeld getippt wird. */
function istTexteingabe(el: Element | null): boolean {
  if (!el) return false;
  const tag = el.tagName.toLowerCase();
  if (tag === "textarea") return true;
  if (tag === "input") {
    const typ = (el as HTMLInputElement).type;
    return ["text", "search", "url", "password", "email", "number"].includes(typ);
  }
  return (el as HTMLElement).isContentEditable === true;
}

export interface TvNavigationOptionen {
  /** Wird bei „Zurück" aufgerufen. Gibt true zurück, wenn behandelt. */
  onBack?: () => boolean;
  /** Wird aufgerufen, wenn zweimal kurz hintereinander „Zurück" kommt. */
  onExitRequest?: () => void;
  /** Abschalten (z. B. während eines Dialogs). */
  aktiv?: boolean;
}

export function useTvNavigation(optionen: TvNavigationOptionen = {}) {
  const { onBack, onExitRequest, aktiv = true } = optionen;
  const letztesZurueck = useRef<number>(0);

  useEffect(() => {
    if (!aktiv) return;

    const onKey = (e: KeyboardEvent) => {
      const ziel = document.activeElement as HTMLElement | null;

      // --- Zurück-Taste der Fernbedienung ---
      // Android sendet sie als "Backspace" oder "GoBack"; im WebView
      // kommt sie oft auch als "Escape" an.
      const istZurueck =
        e.key === "GoBack" ||
        e.key === "BrowserBack" ||
        (e.key === "Backspace" && !istTexteingabe(ziel));

      if (istZurueck) {
        e.preventDefault();
        const jetzt = Date.now();
        // Zweimal innerhalb von 2 Sekunden → Beenden anbieten.
        if (jetzt - letztesZurueck.current < 2000) {
          letztesZurueck.current = 0;
          onExitRequest?.();
          return;
        }
        letztesZurueck.current = jetzt;
        // Erste Betätigung: eine Ebene zurück.
        if (!onBack?.()) {
          window.history.back();
        }
        return;
      }

      // --- Steuerkreuz ---
      const richtungen: Record<string, "up" | "down" | "left" | "right"> = {
        ArrowUp: "up",
        ArrowDown: "down",
        ArrowLeft: "left",
        ArrowRight: "right",
      };
      const richtung = richtungen[e.key];
      if (!richtung) return;

      // In Textfeldern und Schiebereglern arbeiten die Pfeiltasten normal.
      if (istTexteingabe(ziel)) return;
      if (ziel?.tagName === "INPUT" && (ziel as HTMLInputElement).type === "range") {
        if (richtung === "left" || richtung === "right") return;
      }
      // Aufgeklappte Auswahlfelder steuert der Browser selbst.
      if (ziel?.tagName === "SELECT" && (richtung === "up" || richtung === "down")) {
        return;
      }

      const alle = sichtbareElemente();
      if (alle.length === 0) return;

      // Ohne Fokus: erstes Element wählen.
      const von = alle.find((r) => r.el === ziel);
      if (!von) {
        e.preventDefault();
        alle[0].el.focus();
        alle[0].el.scrollIntoView({ block: "nearest", inline: "nearest" });
        return;
      }

      const naechstesEl = naechstes(von, alle, richtung);
      if (naechstesEl) {
        e.preventDefault();
        naechstesEl.focus();
        naechstesEl.scrollIntoView({ block: "nearest", inline: "nearest" });
      }
    };

    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [aktiv, onBack, onExitRequest]);
}
