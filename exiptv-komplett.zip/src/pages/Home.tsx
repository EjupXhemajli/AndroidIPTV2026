import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { backend } from "../lib/backend";
import EmptyState from "../components/EmptyState";
import { useNews, NewsHauptansicht, NewsListe } from "../components/NewsPanel";
import { IconTv } from "../components/Icons";
import type { HistoryEntry, Provider } from "../lib/types";

function greetingKey(): string {
  const h = new Date().getHours();
  if (h < 11) return "home.greetingMorning";
  if (h < 18) return "home.greetingDay";
  return "home.greetingEvening";
}

export default function Home() {
  const { t } = useTranslation();
  const nav = useNavigate();
  const [providers, setProviders] = useState<Provider[] | null>(null);
  const [verlauf, setVerlauf] = useState<HistoryEntry[] | null>(null);
  const { items, failed } = useNews();
  const [index, setIndex] = useState(0);

  useEffect(() => {
    backend.listProviders().then(setProviders).catch(() => setProviders([]));
    // Zuletzt angesehen: die letzten Einträge des Wiedergabeverlaufs.
    backend.listHistory().then((h) => setVerlauf(h.slice(0, 6))).catch(() => setVerlauf([]));
  }, []);

  return (
    <>
      <header>
        <h1>{t(greetingKey())}</h1>
        <p className="dim">{t("home.subtitle")}</p>
      </header>

      {providers === null && (
        <div className="row" style={{ gap: "var(--gap-m)" }}>
          <div className="skeleton" style={{ height: 120, flex: 1 }} />
          <div className="skeleton" style={{ height: 120, flex: 1 }} />
          <div className="skeleton" style={{ height: 120, flex: 1 }} />
        </div>
      )}

      {providers !== null && providers.length === 0 && (
        <EmptyState
          title={t("home.getStartedTitle")}
          text={t("home.getStartedText")}
          action={
            <button className="primary" onClick={() => nav("/providers")}>
              {t("home.getStartedAction")}
            </button>
          }
        />
      )}

      {providers !== null && providers.length > 0 && (
        <div className="home-layout">
          {/* Links: große Nachrichtenansicht */}
          <NewsHauptansicht items={items} failed={failed} index={index} setIndex={setIndex} />

          {/* Rechts: weitere Schlagzeilen und der Verlauf */}
          <div className="home-rechts">
            <NewsListe items={items} failed={failed} index={index} setIndex={setIndex} />

            <section className="card">
              <h2>{t("home.recentChannels")}</h2>
              {verlauf === null && (
                <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="skeleton" style={{ height: 44 }} />
                  ))}
                </div>
              )}
              {verlauf !== null && verlauf.length === 0 && (
                <p className="dim" style={{ marginTop: 8 }}>{t("empty.history")}</p>
              )}
              {verlauf !== null && verlauf.length > 0 && (
                <div className="home-verlauf">
                  {verlauf.map((h) => (
                    <button
                      key={`${h.item_type}:${h.item_id}`}
                      className="home-verlauf-eintrag"
                      onClick={() => nav("/history")}
                      title={h.name}
                    >
                      <span className="home-verlauf-logo">
                        {h.logo_url ? <img src={h.logo_url} alt="" loading="lazy" /> : <IconTv />}
                      </span>
                      <span className="home-verlauf-name">{h.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </section>
          </div>
        </div>
      )}
    </>
  );
}
