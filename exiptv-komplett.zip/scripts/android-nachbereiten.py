#!/usr/bin/env python3
"""
Bereitet das von `tauri android init` erzeugte Android-Projekt nach.

`tauri android init` legt unter src-tauri/gen/android ein Gradle-Projekt an.
Dieses Skript ergänzt darin, was EXIPTV zusätzlich braucht:

1. **Berechtigungen** – ohne INTERNET kann die App weder Playlisten laden
   noch Streams abspielen. Viele IPTV-Server liefern zudem über http://
   statt https://, deshalb wird Klartext-Verkehr erlaubt.
2. **Wiedergabe-Plugin** – die Kotlin-Dateien aus android-plugin/ werden in
   das erzeugte Projekt kopiert.
3. **Media3/ExoPlayer** – die Abhängigkeiten für die Videowiedergabe.

Das Skript ist mehrfach ausführbar: Bereits vorhandene Einträge werden
nicht doppelt eingefügt.
"""

from pathlib import Path
import os
import re
import shutil
import sys

MEDIA3 = "1.4.1"

BERECHTIGUNGEN = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.WAKE_LOCK",
]

# Merkmale für Fernseher-Geräte (Fire TV, Formuler, Philips/Sony Android TV).
#
# - leanback (required=false): Die App läuft auf Fernsehern UND auf Telefonen.
#   Stünde required=true, ließe sie sich auf Telefonen nicht installieren.
# - touchscreen (required=false): Fernseher haben keinen Berührungsbildschirm.
#   Ohne diesen Eintrag lehnen TV-Geräte die Installation ab.
GERAETE_MERKMALE = [
    ("android.software.leanback", "false"),
    ("android.hardware.touchscreen", "false"),
    ("android.hardware.faketouch", "false"),
]


def mipmap_vorhanden(app: Path) -> bool:
    """Prüft, ob die Symbol-Ressource `mipmap/ic_launcher` erzeugt wurde.

    Wird im Manifest auf eine Ressource verwiesen, die es nicht gibt,
    scheitert der Gradle-Build mit „resource mipmap/ic_launcher not found".
    Deshalb wird der TV-Banner nur gesetzt, wenn das Symbol wirklich da ist.
    """
    res = app / "src" / "main" / "res"
    if not res.is_dir():
        return False
    for ordner in res.glob("mipmap*"):
        if any(ordner.glob("ic_launcher*")):
            return True
    return False


def manifest_anpassen(manifest: Path, banner_erlaubt: bool = True) -> None:
    if not manifest.is_file():
        print(f"WARNUNG: {manifest} nicht gefunden – Berechtigungen nicht gesetzt.")
        return

    text = manifest.read_text(encoding="utf-8")
    original = text

    # Fehlende Berechtigungen direkt nach dem <manifest …>-Tag einfügen.
    fehlend = [p for p in BERECHTIGUNGEN if p not in text]
    if fehlend:
        zeilen = "".join(
            f'\n    <uses-permission android:name="{p}" />' for p in fehlend
        )
        text = re.sub(r"(<manifest\b[^>]*>)", r"\1" + zeilen, text, count=1)
        print(f"Berechtigungen ergänzt: {', '.join(fehlend)}")

    # Geräte-Merkmale für Fernseher ergänzen.
    fehlende_merkmale = [
        (name, req) for name, req in GERAETE_MERKMALE if f'"{name}"' not in text
    ]
    if fehlende_merkmale:
        zeilen = "".join(
            f'\n    <uses-feature android:name="{n}" android:required="{r}" />'
            for n, r in fehlende_merkmale
        )
        text = re.sub(r"(<manifest\b[^>]*>)", r"\1" + zeilen, text, count=1)
        print(f"Geräte-Merkmale ergänzt: {', '.join(n for n, _ in fehlende_merkmale)}")

    # Startmenü-Eintrag für Fernseher (LEANBACK_LAUNCHER).
    # Ohne ihn erscheint die App auf Fire TV & Co. nicht im Startbildschirm.
    if "LEANBACK_LAUNCHER" not in text:
        text = text.replace(
            '<category android:name="android.intent.category.LAUNCHER" />',
            '<category android:name="android.intent.category.LAUNCHER" />\n'
            '                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />',
            1,
        )
        print("Startmenü-Eintrag für Fernseher ergänzt (LEANBACK_LAUNCHER)")

    # Banner für die Fernseher-Oberfläche (Fire TV zeigt Kacheln statt Symbole).
    # Nur setzen, wenn das Symbol wirklich existiert – sonst bricht Gradle ab.
    if banner_erlaubt and "android:banner" not in text:
        text = re.sub(
            r"(<application\b)",
            lambda m: m.group(1) + ' android:banner="@mipmap/ic_launcher"',
            text,
            count=1,
        )
        print("TV-Banner gesetzt")
    elif not banner_erlaubt:
        print("TV-Banner übersprungen: Symbol mipmap/ic_launcher nicht gefunden.")

    # Klartext-HTTP erlauben (viele IPTV-Server nutzen http://).
    if "usesCleartextTraffic" not in text:
        text = re.sub(
            r"(<application\b)",
            r'\1 android:usesCleartextTraffic="true"',
            text,
            count=1,
        )
        print("Klartext-HTTP erlaubt (android:usesCleartextTraffic)")

    if text != original:
        manifest.write_text(text, encoding="utf-8")
    else:
        print("Manifest war bereits vollständig.")


def plugin_kopieren(quelle: Path, ziel: Path) -> None:
    if not quelle.is_dir():
        print(f"Hinweis: {quelle} nicht vorhanden – Plugin wird übersprungen.")
        return
    ziel.mkdir(parents=True, exist_ok=True)
    anzahl = 0
    for datei in quelle.glob("*.kt"):
        shutil.copy2(datei, ziel / datei.name)
        anzahl += 1
    print(f"{anzahl} Kotlin-Datei(en) kopiert nach {ziel}")


def gradle_anpassen(gradle: Path) -> None:
    if not gradle.is_file():
        print(f"WARNUNG: {gradle} nicht gefunden – Media3 nicht ergänzt.")
        return
    text = gradle.read_text(encoding="utf-8")
    if "media3-exoplayer" in text:
        print("Media3-Abhängigkeiten waren bereits vorhanden.")
        return

    eintraege = (
        "\n    // Videowiedergabe (ExoPlayer / Media3) – von EXIPTV ergänzt\n"
        f'    implementation("androidx.media3:media3-exoplayer:{MEDIA3}")\n'
        f'    implementation("androidx.media3:media3-exoplayer-hls:{MEDIA3}")\n'
        f'    implementation("androidx.media3:media3-exoplayer-dash:{MEDIA3}")\n'
        f'    implementation("androidx.media3:media3-ui:{MEDIA3}")\n'
    )

    stelle = text.rfind("dependencies {")
    if stelle < 0:
        print("WARNUNG: dependencies-Block nicht gefunden – Media3 nicht ergänzt.")
        return
    zeilenende = text.index("\n", stelle) + 1
    text = text[:zeilenende] + eintraege + text[zeilenende:]
    gradle.write_text(text, encoding="utf-8")
    print("Media3-Abhängigkeiten ergänzt.")


def main() -> int:
    wurzel = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".")
    app = wurzel / "src-tauri" / "gen" / "android" / "app"

    if not app.is_dir():
        print(f"FEHLER: {app} nicht gefunden. Lief 'tauri android init' durch?")
        return 1

    print(f"Android-Projekt: {app}")
    banner_ok = mipmap_vorhanden(app)
    manifest_anpassen(app / "src" / "main" / "AndroidManifest.xml", banner_ok)

    # Natives Wiedergabe-Plugin (ExoPlayer) nur auf ausdrücklichen Wunsch.
    #
    # Die Tauri-Plugin-Schnittstelle (@TauriPlugin) verlangt einen eigenen
    # Registrierungsschritt; ein bloßes Hineinkopieren der Kotlin-Datei
    # reicht nicht und lässt den Gradle-Build scheitern. Bis das sauber
    # eingebunden ist, spielt Android über den im System eingebauten
    # Videoplayer der WebView ab.
    #
    # Zuschalten mit:  EXIPTV_NATIVER_PLAYER=1
    if os.environ.get("EXIPTV_NATIVER_PLAYER") == "1":
        plugin_kopieren(
            wurzel / "android-plugin" / "src" / "main" / "java" / "de" / "exiptv" / "player",
            app / "src" / "main" / "java" / "de" / "exiptv" / "player",
        )
        gradle_anpassen(app / "build.gradle.kts")
    else:
        print("Nativer Player übersprungen (EXIPTV_NATIVER_PLAYER nicht gesetzt).")
        print("Die Wiedergabe läuft über den Videoplayer der WebView.")
    print("Nachbereitung abgeschlossen.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
