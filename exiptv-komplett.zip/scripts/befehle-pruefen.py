#!/usr/bin/env python3
"""
Prüft, ob alle in lib.rs registrierten Tauri-Befehle wirklich existieren.

Hintergrund: Ein Tippfehler in der Befehlsliste fällt erst beim
Kompilieren auf – auf Android nach rund sechs Minuten Build-Zeit.
Dieses Skript findet solche Fehler in unter einer Sekunde.

Geprüft wird:
1. Jeder in `generate_handler![…]` registrierte Befehl ist mit
   `#[tauri::command]` definiert – getrennt je Plattform-Liste.
2. Das Frontend ruft keinen Befehl auf, den es nirgends gibt.

Aufruf:  python3 scripts/befehle-pruefen.py
Rückgabe: 0 = alles in Ordnung, 1 = Fehler gefunden
"""

from pathlib import Path
import re
import sys

WURZEL = Path(__file__).resolve().parent.parent

# Module, in denen Tauri-Befehle stehen können.
MODULE = {
    "commands": "src-tauri/src/commands.rs",
    "playback_commands": "src-tauri/src/playback_commands.rs",
    "android_playback": "src-tauri/src/android_playback.rs",
}


def befehle_im_modul(pfad: Path) -> set[str]:
    """Namen aller mit #[tauri::command] markierten Funktionen."""
    if not pfad.is_file():
        return set()
    quelle = pfad.read_text(encoding="utf-8")
    return set(
        re.findall(r"#\[tauri::command\]\s*(?:pub\s+)?(?:async\s+)?fn\s+(\w+)", quelle)
    )


def main() -> int:
    definiert: dict[str, set[str]] = {
        name: befehle_im_modul(WURZEL / pfad) for name, pfad in MODULE.items()
    }

    lib = (WURZEL / "src-tauri/src/lib.rs").read_text(encoding="utf-8")
    listen = re.findall(r"generate_handler!\[(.*?)\n        \]", lib, re.S)
    if not listen:
        print("FEHLER: Keine Befehlsliste in lib.rs gefunden.")
        return 1

    fehler = 0
    for nummer, liste in enumerate(listen, start=1):
        eintraege = re.findall(r"(\w+)::(\w+)", liste)
        for modul, befehl in eintraege:
            if modul not in definiert:
                print(f"  ✗ Liste {nummer}: unbekanntes Modul „{modul}“ ({befehl})")
                fehler += 1
            elif befehl not in definiert[modul]:
                print(f"  ✗ Liste {nummer}: „{modul}::{befehl}“ ist nicht definiert")
                fehler += 1
        print(f"  Liste {nummer}: {len(eintraege)} Befehle geprüft")

    # Frontend gegen alle bekannten Befehle prüfen.
    bridge = WURZEL / "src/lib/backend.ts"
    if bridge.is_file():
        quelle = bridge.read_text(encoding="utf-8")
        aufgerufen = set(re.findall(r"inv\b[^\"']*[\"']([a-z_]+)[\"']", quelle))
        aufgerufen |= set(re.findall(r"\"(android_\w+)\"", quelle))
        alle: set[str] = set()
        for menge in definiert.values():
            alle |= menge
        unbekannt = sorted(aufgerufen - alle)
        if unbekannt:
            print("  ✗ Frontend ruft nicht vorhandene Befehle auf:")
            for b in unbekannt:
                print(f"      {b}")
            fehler += len(unbekannt)
        else:
            print(f"  Frontend: {len(aufgerufen)} Aufrufe geprüft")

    if fehler:
        print(f"\n✗ {fehler} Fehler gefunden – der Build würde scheitern.")
        return 1
    print("\n✓ Alle Befehle stimmen überein.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
